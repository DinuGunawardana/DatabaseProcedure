/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqlconnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* *
 * @author DELL
 */
public class Sqlconnect {

    /**
     * @param args the command line arguments
     */
   // public static void main(String[] args) {
        // TODO code application logic here
        /*SuperMarket rgf = new SuperMarket();
        rgf.setVisible(true);
        getConnection();
    }
    
    static Connection getConnection()  {
         Connection con = null;
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;user=sa;password=1997sandunsuneth;" +
            "databaseName=SperMarket");
            System.out.println("Connected database successfully...");
            //return con;
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return con;*/
    
    public static Connection Connect() throws ClassNotFoundException
    {
        Connection con = null;
        
        String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=SperMarket;user=sa;password=1997sandunsuneth";
        
        try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con=DriverManager.getConnection(connectionURL);
            if(con!=null)
            {
                System.out.println("Connected");
            }
            else
            {
                System.out.println("Error while Connecting");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Sqlconnect.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }  
        
        
    }
    

